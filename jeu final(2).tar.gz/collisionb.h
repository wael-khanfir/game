#ifndef COLLISIONB_H
#define COLLISIONB_H
#include <SDL/SDL.h>
int check_collision(SDL_Rect A,SDL_Rect B );
#endif
