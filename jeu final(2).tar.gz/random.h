#ifndef RANDOM_H_INCLUDED
#define RANDOM_H_INCLUDED

int nombre(void);

#endif // RANDOM_H_INCLUDED
